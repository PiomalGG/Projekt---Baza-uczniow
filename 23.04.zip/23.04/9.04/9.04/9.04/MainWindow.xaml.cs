﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;

namespace _9._04
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    class Osoba
    {
        public string? n_PESEL { get; set; }
        public string? n_Imie { get; set; }
        public string? n_DImie { get; set; }
        public string? n_Nazwisko { get; set; }
        public Osoba()
        {
            n_PESEL = "00000000000";
            n_Imie = "";
            n_DImie = "";
            n_Nazwisko = "";
        } 
    }
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            AddWindow AddWin = new AddWindow();
            AddWin.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            InfoWindow InfWin = new InfoWindow();
            InfWin.Show();
            this.Close();
        }
        

        private void SaveFile_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            saveFileDialog.Title = "Zapisz jako plik CSV";
            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                string delimiter = ";";
                if (saveFileDialog.FilterIndex == 1)
                {
                    delimiter = ",";
                }
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (Osoba item in listView.Items)
                    {
                        var row = $"{item.n_PESEL}{delimiter}{item.n_Imie}" +
                        $"{delimiter}{item.n_DImie}{delimiter}{item.n_Nazwisko}";
                        writer.WriteLine(row);
                    }
                }
            }
        }


        private void AddFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Pliki CSV z separatorem (,) |*.csv|Pliki CSV z separatorem (;) |*.csv";
            openFileDialog.Title = "Otwórz plik CSV";
            if (openFileDialog.ShowDialog() == true)
            {
                listView.Items.Clear();
                string filePath = openFileDialog.FileName;
                int selectedFilterIndex = openFileDialog.FilterIndex;
                string delimiter = ";";
                if (selectedFilterIndex == 1)
                {
                    delimiter = ",";
                }
                Encoding encoding = Encoding.UTF8;
                if (File.Exists(filePath))
                {
                    var lines = File.ReadAllLines(filePath, encoding);
                    foreach (var line in lines)
                    {
                        string[] columns = line.Split(delimiter);
                        if (columns != null)
                        {
                            Osoba uczen = new();
                            uczen.n_PESEL = columns.ElementAtOrDefault(0);
                            uczen.n_Imie = columns.ElementAtOrDefault(1);
                            uczen.n_DImie = columns.ElementAtOrDefault(2);
                            uczen.n_Nazwisko = columns.ElementAtOrDefault(3);
                            listView.Items.Add(uczen);
                        }
                    }
                }

            }
        }

        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
