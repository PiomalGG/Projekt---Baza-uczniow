﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace _9._04
{
    public partial class AddWindow : Window
    {
        public AddWindow()
        {
            InitializeComponent();
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            if(PESELtxt.Text != "" || Imietxt.Text != "" || DImietxt.Text != "" || Nazwiskotxt.Text != "" || DataUrtxt.Text != "" || NrTeltxt.Text != "" || Adrestxt.Text != "" || Miejscowosctxt.Text != "" || KodPttxt.Text != "")
            {
                var potwierdzenie = MessageBox.Show("Wprowadzono dane do pól, czy na pewno chcesz zamknąć okno? Wprowadzone dane zostaną wtedy usunięte.",
                                     "Potwierdzenie",
                                     MessageBoxButton.YesNo,
                                     MessageBoxImage.Warning);
                if (potwierdzenie == MessageBoxResult.Yes)
                {
                    this.Close();
                }
            }
            else
            {
                this.Close();
            }
        }

        private void DodajDane(object sender, RoutedEventArgs e)
        {
            if(PESELtxt.Text == "" || Imietxt.Text == "" || Nazwiskotxt.Text == "" || DataUrtxt.Text == "" || Adrestxt.Text == "" || Miejscowosctxt.Text == "" || KodPttxt.Text == "")
            {
                MessageBox.Show("Wszystkie pola oznaczone gwiazdką (*) są obowiązkowe!",
                        "Błąd",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
            }
            else
            {
                MainWindow? mainWindow = Owner as MainWindow;
                Osoba uczen = new();
                mainWindow.listView.Items.Add(uczen);
                uczen.n_PESEL = PESELtxt.Text;
                string imie = Imietxt.Text;
                if (Imietxt.Text.Length > 0)
                {
                    imie = imie.Trim();
                    imie = char.ToUpper(imie[0]) + imie.Substring(1).ToLower();
                    uczen.n_Imie = imie;
                }
                else
                {
                    uczen.n_Nazwisko = "";
                }
                string dimie = DImietxt.Text;
                if (DImietxt.Text.Length > 0)
                {
                    dimie = dimie.Trim();
                    dimie = char.ToUpper(dimie[0]) + dimie.Substring(1).ToLower();
                    uczen.n_DImie = dimie;
                }
                else
                {
                    uczen.n_DImie = "";
                }
                string nazwisko = Nazwiskotxt.Text;
                if (Nazwiskotxt.Text.Length > 0)
                {
                    nazwisko = nazwisko.Trim();
                    nazwisko = char.ToUpper(nazwisko[0]) + nazwisko.Substring(1).ToLower();
                    uczen.n_Nazwisko = nazwisko;
                }
                else
                {
                    uczen.n_Nazwisko = "0000000000";
                }
                uczen.n_DataUr = DataUrtxt.Text;
                string NrTel = NrTeltxt.Text;
                if (NrTeltxt.Text.Length > 0)
                {
                    NrTel = NrTel.Replace(" ", "");
                    if (!NrTel.StartsWith("+48"))
                    {
                        if (NrTel.StartsWith("0"))
                        {
                            NrTel = NrTel.Substring(1);
                        }

                        NrTel = "+48" + NrTel;
                    }
                    uczen.n_NrTel = NrTel;
                }
                else
                {
                    uczen.n_NrTel = NrTeltxt.Text;
                }
                uczen.n_Adres = Adrestxt.Text;
                uczen.n_Miejscowosc = Miejscowosctxt.Text;
                uczen.n_KodPt = KodPttxt.Text;
            }
        }
    }
}
